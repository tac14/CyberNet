-- MySQL dump 10.13  Distrib 5.6.10, for Win32 (x86)
--
-- Host: localhost    Database: cybernetdb
-- ------------------------------------------------------
-- Server version	5.6.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `cybernetdb`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `cybernetdb` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `cybernetdb`;

--
-- Table structure for table `actions`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `actions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(45) NOT NULL,
  `Type` int(11) NOT NULL DEFAULT '0',
  `EnergyIndex` int(11) NOT NULL DEFAULT '0',
  `DangerIndex` int(11) NOT NULL DEFAULT '0',
  `ForceIndex` int(11) NOT NULL DEFAULT '0',
  `IntelligenceIndex` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Name_UNIQUE` (`Name`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actions`
--

INSERT INTO `actions` (`ID`, `Name`, `Type`, `EnergyIndex`, `DangerIndex`, `ForceIndex`, `IntelligenceIndex`) VALUES (1,'Кушать',1,10,0,0,0),(2,'Спать',1,10,0,0,0),(3,'Лечиться',1,200,0,0,0),(4,'Собрать',0,100,1,1,1),(5,'Готовить еду',0,0,0,0,0),(6,'Охотиться',0,0,0,0,0),(7,'Плавить',0,0,0,0,0),(8,'Обработать',0,0,0,0,0),(9,'Повалить',0,0,0,0,0),(10,'Рубить',0,0,0,0,0),(11,'Резать',0,0,0,0,0),(12,'Прибивать',0,0,0,0,0),(13,'Стругать',0,0,0,0,0);

--
-- Table structure for table `agents`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `agents` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(45) NOT NULL,
  `Energy` int(11) NOT NULL DEFAULT '100',
  `Health` int(11) NOT NULL DEFAULT '100',
  `Force` int(11) NOT NULL DEFAULT '0',
  `Intelligence` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agents`
--

INSERT INTO `agents` (`ID`, `Name`, `Energy`, `Health`, `Force`, `Intelligence`) VALUES (1,'tac',80,100,0,0),(2,'tac2',70,100,0,0),(3,'test',100,100,0,0);

--
-- Table structure for table `categories`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `categories` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(45) NOT NULL,
  `Type` varchar(45) NOT NULL,
  `Measure` varchar(10) DEFAULT NULL,
  `EnergyIndex` int(11) DEFAULT '0',
  `CollectIndex` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`ID`, `Name`, `Type`, `Measure`, `EnergyIndex`, `CollectIndex`) VALUES (1,'Ничего','Special','',0,0),(2,'Еда','Special','калорий',0,0),(3,'Ягоды','Plants','кг.',300,2),(4,'Деревья','Plants','шт.',0,0),(5,'Железо','Minerals','кг.',0,0),(6,'Балки','Product','куб.м.',0,0),(7,'Топор','Product','шт.',0,0),(8,'Пила','Product','шт.',0,0),(9,'Копьё','Product','шт.',0,0),(10,'Олени','Animals','шт.',0,0),(11,'Мясо','Product','кг.',1000,50),(12,'Доски','Product','куб.м.',0,0),(13,'Гвозди','Product','кг.',0,0),(14,'Молоток','Product','шт.',0,0),(15,'Жилище','Product','шт.',0,0);

--
-- Table structure for table `categoriesprevalence`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `categoriesprevalence` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Prevalence` double NOT NULL DEFAULT '0',
  `PrevalenceFluctuation` double NOT NULL DEFAULT '0',
  `QualityNorm` double NOT NULL DEFAULT '0',
  `QualityFluctuation` double NOT NULL DEFAULT '0',
  `CategoryID` int(11) NOT NULL,
  `CityID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `fk_CategoriesPrevalence_categories1_idx` (`CategoryID`),
  KEY `fk_CategoriesPrevalence_world1_idx` (`CityID`),
  CONSTRAINT `fk_CategoriesPrevalence_categories1` FOREIGN KEY (`CategoryID`) REFERENCES `categories` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_CategoriesPrevalence_world1` FOREIGN KEY (`CityID`) REFERENCES `world` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoriesprevalence`
--

INSERT INTO `categoriesprevalence` (`ID`, `Prevalence`, `PrevalenceFluctuation`, `QualityNorm`, `QualityFluctuation`, `CategoryID`, `CityID`) VALUES (1,30,5,20,5,2,1);

--
-- Table structure for table `optionsconditionsactionexe`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `optionsconditionsactionexe` (
  `OptionID` int(11) NOT NULL,
  `ConditionID` int(11) NOT NULL,
  `ActionsID` int(11) NOT NULL,
  `CategoryID` int(11) NOT NULL,
  KEY `fk_OptionsConditionsActionExe_categories1_idx` (`CategoryID`),
  KEY `fk_OptionsConditionsActionExe_Actions1` (`ActionsID`),
  CONSTRAINT `fk_OptionsConditionsActionExe_Actions1` FOREIGN KEY (`ActionsID`) REFERENCES `actions` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_OptionsConditionsActionExe_categories1` FOREIGN KEY (`CategoryID`) REFERENCES `categories` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `optionsconditionsactionexe`
--


--
-- Table structure for table `optionsreceivingproduct`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `optionsreceivingproduct` (
  `OptionsID` int(11) NOT NULL,
  `FromID` int(11) NOT NULL DEFAULT '0',
  `FromOptionsID` int(11) NOT NULL DEFAULT '0',
  `ToID` int(11) NOT NULL,
  `ActionID` int(11) NOT NULL,
  KEY `fk_OptionsReceivingProduct_Actions1_idx` (`ActionID`),
  CONSTRAINT `fk_OptionsReceivingProduct_Actions1` FOREIGN KEY (`ActionID`) REFERENCES `actions` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `optionsreceivingproduct`
--


--
-- Table structure for table `stock`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `stock` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Count` double DEFAULT '0',
  `Quality` double DEFAULT '0',
  `AgentID` int(11) NOT NULL,
  `CategoryID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `fk_stock_agents_idx` (`AgentID`),
  KEY `fk_stock_categories1_idx` (`CategoryID`),
  CONSTRAINT `fk_stock_agents` FOREIGN KEY (`AgentID`) REFERENCES `agents` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_stock_categories1` FOREIGN KEY (`CategoryID`) REFERENCES `categories` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock`
--


--
-- Table structure for table `test`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `test` (
  `ID` int(11) NOT NULL,
  `Name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`ID`, `Name`) VALUES (1,'Test1'),(2,'Test2');

--
-- Table structure for table `world`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `world` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `City` varchar(100) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `City_UNIQUE` (`City`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `world`
--

INSERT INTO `world` (`ID`, `City`) VALUES (1,'Рига');
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-05-05 22:38:07
